<?php

	$db_host ="localhost";
	$db_user = "root";
	$db_pass = "";
	$db_name = "sakila";

	$conexion = new mysqli($db_host, $db_user, $db_pass, $db_name);

	$sql = "SELECT *
			FROM `category` WHERE 1";

	$resultado = $conexion->query($sql) 
				or die(mysqli_errno($this->conexion)." : " 
				.mysqli_error($conexion)." | Query=".$sql);

	
	/*$primerRegistro = $resultado->fetch_assoc();

	print_r($primerRegistro);	*/

	$listado =array();
	while($fila = $resultado->fetch_assoc()){
			$listado[]=$fila;
	}

	$conexion->close();
?>

<html>
	<head>
		<meta charset="utf-8">
		<title>Gestor de Categorias</title>
		<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.11/css/dataTables.bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
        <link href="css/bootstrap.min.css" rel="stylesheet"> 
        <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
      .table-striped>tbody>tr:nth-child(even)>td, 
      .table-striped>tbody>tr:nth-child(even)>th {
       background-color: #ff0;
      }
      .table-striped>tbody>tr:nth-child(even)>td, 
      .table-striped>tbody>tr:nth-child(even)>th {
       background-color: #ccc;
      }
      .table-striped>thead>tr>th {
         background-color: #eee;
      }
    </style>

    <meta name="viewport" content="width=device-width, initial-scale=1">
        
	<body>
    <div class="container">
    <img src="C:\xampp\htdocs\peliculas\imagen1.png" class="img-rounded">
    <hr>
        <h1 align="center" class="p-3 mb-2 bg-primary text-white" class="panel panel-success" >Gestor de Categorias</h1>
        <div class="p-3 mb-2 bg-success text-dark" >

        <label for="ejemplo_email_1">Categoria</label>
         <input type="email" class="form-control" id="ejemplo_email_1"
           placeholder="Ingrese numero categoria">

        <label for="ejemplo_email_1">Nombre</label>
         <input type="email" class="form-control" id="ejemplo_email_1"
           placeholder="Ingrese nombre categoria">
            
        <table id="tabla" align="center" class="table table-striped table-bordered table-hover" text-dark "cellspacing="0" width="60%">			
			<thead>
				<tr>
					<th>Categoria</th>
					<th>Nombre</th>
                    <th>Fecha actualizada</th>      

                </tr>
			</thead>
			<tbody>
				<?php foreach($listado as $fila){ ?>
				<tr>
					<td><?php echo $fila['category_id'] ?> </td>
					<td><?php echo utf8_encode($fila['name']) ?> </td>
                    <td><?php echo utf8_encode($fila['last_update']) ?>
                    <button type="button" class="btn btn-success">Insertar</button> 
                    <button type="button" class="btn btn-primary">Borrar</button>  </td> 
                    
                </tr>
                <?php } ?>
                
                </div>
			</tbody>
        </table>
        </div>

		<!-- jQuery 2.1.4 -->
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
	    <<script src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
	    <script src="https://cdn.datatables.net/1.10.11/js/dataTables.bootstrap.min.js"></script>
	    <!-- jQuery UI 1.11.4 -->
	    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
	    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	    
	    <!-- Bootstrap 3.3.5 -->
    	<script src="bootstrap/js/bootstrap.min.js"></script>
    	<!-- Funciones de Lógica de neogcio -->
		<script>
    		$(document).ready(function(){
    			$("#tabla").DataTable();
    		});
		</script>
	</body>
</html>
